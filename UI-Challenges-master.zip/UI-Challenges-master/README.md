# Habib Dev. UI Challenges Project
IONIC Framework, Angular Framework UI Challenges and Collections.  

![Habib-UI-Challenges](https://user-images.githubusercontent.com/31030616/87856306-57afb400-c92f-11ea-94ae-012556f77d42.png)

In this project am adding my design and development of varuise applications that I made during my free time.
Please feel free to use my examples and don't forget to credit my work :smirk_cat:.  

## Project List:
01. <a href="https://github.com/habibalmawali/UI-Challenges/tree/master/ionic-restrant-app">Restaurant Menu App 🔥</a>
02. <a href="https://github.com/habibalmawali/UI-Challenges/tree/master/ionic-project-management">Project Management App 🔥</a>
03. <a href="https://github.com/habibalmawali/UI-Challenges/tree/master/ionic-covid19-guide">Covid-19 Guide App 🔥</a>
04. <a href="https://github.com/habibalmawali/UI-Challenges/tree/master/ionic-movies">Movies App 🔥</a>
05. <a href="https://github.com/habibalmawali/UI-Challenges/tree/master/ionic-car-rental">Car Rental App 🔥</a>
06. <a href="https://github.com/habibalmawali/UI-Challenges/tree/master/ionic-pokedex">Pokemon PokeDex App 🔥</a>
07. <a href="https://github.com/habibalmawali/UI-Challenges/tree/master/ionic-flowers-store">Flowers Store App 🔥</a>
08. <a href="https://github.com/habibalmawali/prototype-into-real">Headset Store 🔥</a>
09. <a href="https://github.com/thedevclass/ionic-components-library/tree/shoes-card">Puma Shoes Card 🔥</a>
10. <a href="https://github.com/thedevclass/ionic-components-library/tree/stories">Stories Section 🔥</a>


###### Thank you.

**Note that I am not responsible for any misuse of any of my projects.**

> Habib AlMawali :smirk_cat:
